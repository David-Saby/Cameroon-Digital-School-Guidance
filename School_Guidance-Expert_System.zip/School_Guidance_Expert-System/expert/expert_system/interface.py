from sysexpert import Fait, BaseDeRegles, BaseDeFaits, AnalyseurSyntaxique, MoteurDInferance

def lire_regles(basederegles):
	basedefaits = BaseDeFaits()
	AnalyseurSyntaxique.analyse_fichier('regle_siop.txt', basedefaits, basederegles)

def lire_faits(dict_faits, basedefaits):
	for cle in dict_faits:
		basedefaits.ajouter(Fait(dict_faits[cle], True))

def recuperer_liste_metiers(dict_faits):
	basederegles = BaseDeRegles()
	basedefaits = BaseDeFaits()

	lire_regles(basederegles)
	lire_faits(dict_faits, basedefaits)

	liste_metiers = []
	moteur_d_inference = MoteurDInferance()
	
	# Metier de l'informatique
	valide = moteur_d_inference.chainage_avant(basedefaits, basederegles, Fait("MI", True))
	if valide:
		liste_metiers.append("Les métiers de l'informatique : nous vous suggerons de faire la formation de Génie Informatique à la FTIC")
	
	# Metier des Telecoms
	valide = moteur_d_inference.chainage_avant(basedefaits, basederegles, Fait("MT", True))
	if valide:
		liste_metiers.append("Les métiers des Télécommunications : nous vous suggerons de faire la formation de Génie des Télécommunications à la FTIC")

	# Metier de l'electronique
	valide = moteur_d_inference.chainage_avant(basedefaits, basederegles, Fait("ME", True))
	if valide:
		liste_metiers.append("Les métiers de l'electronique : nous vous suggerons de faire la formation de Génie Electronique à la FTIC")
	
	# Metier de la sante
	valide = moteur_d_inference.chainage_avant(basedefaits, basederegles, Fait("MS", True))
	if valide:
		liste_metiers.append("Les métiers de la santé : nous vous suggerons de faire la formation en Sciences Infirmières à la FSS")
	return liste_metiers