from django.urls import include, path
from django.contrib import admin
from . import views
from expert.views import professions

app_name = 'expert'

urlpatterns = [
	path('', views.home, name='home'),
	path('login/', views.login_view, name='login'),
	path('logout/', views.logout_view, name='logout'),
	path('signup/', views.signup, name='signup'),
	path('professions', views.professions, name='professions'),
	path('evaluation/', views.evaluation, name='evaluation'),
	path('results/', views.results, name='results'),
	
]


admin.site.site_header = 'Administration SIOSCAM'                    # default: "Django Administration"
admin.site.index_title = 'Page Administration'                       # default: "Site administration"
admin.site.site_title = 'Administration du SIOSCAM'           # default: "Django site admin"
